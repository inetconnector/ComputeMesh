"""ComputeMesh Appliance Dashboard."""
