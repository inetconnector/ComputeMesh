# -*- mode: python ; coding: utf-8 -*-


a = Analysis(
    ['tools/appliance/windows_tray_app.py'],
    pathex=[],
    binaries=[],
    datas=[('services/appliance_dashboard/static', 'services/appliance_dashboard/static'), ('services/common', 'services/common')],
    hiddenimports=['PIL', 'PIL.Image', 'pystray', 'tkinter', 'urllib.request'],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='ComputeMesh',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=['assets/icon.ico'],
)
coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name='ComputeMesh',
)
