"""Unit tests for LocalCapacityGuard."""
